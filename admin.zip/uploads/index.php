<?php
// Proteksi direktori uploads dari akses langsung
header('HTTP/1.0 403 Forbidden');
exit('Access denied.');
?>
